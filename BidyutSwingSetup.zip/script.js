
function showReport() {
  document.getElementById("reportBox").innerHTML = `
    <h3>AI Financial Snapshot:</h3>
    <ul>
      <li><strong>Profit & Loss:</strong> ₹52 Cr (YoY ↑ 18%)</li>
      <li><strong>Balance Sheet:</strong> Strong with low debt</li>
      <li><strong>Cash Flow:</strong> Positive operating cash</li>
      <li><strong>Ratios:</strong> ROE 18%, ROCE 22%</li>
      <li><strong>Investor Ignored:</strong> Undervalued midcap</li>
    </ul>
  `;
}
